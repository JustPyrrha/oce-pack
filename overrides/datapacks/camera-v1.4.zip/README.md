# camera
> `/trigger camera` command to swap b/w spectator and survival modes

Designed for the hermitcraft camera accounts used for footage.

## Usage

`/trigger camera` to swap between spectator and survival!

## Developing

To make a new release, just push a commit with a message starting with `release: ` and the rest of the message will be used as the release title.
