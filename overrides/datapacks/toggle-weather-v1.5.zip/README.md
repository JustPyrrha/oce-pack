# toggle-weather
> Simple triggers to toggle both rain and thunder

## Usage

- `/trigger rain` to toggle rain.
- `/trigger thunder` to toggle thunder.

## Developing

To make a new release, just push a commit with a message starting with `release: ` and the rest of the message will be used as the release title.
